module.exports = {
  lintOnSave: false,
  devServer: {
    port: 8081
  }
}