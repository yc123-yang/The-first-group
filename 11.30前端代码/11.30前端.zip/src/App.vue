<template>
  <div id="app" style="min-width: 1300px;">
    <router-view></router-view>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
